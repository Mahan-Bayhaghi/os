
gcc thread_pool_size.c -pthread -o tps.o
./tps.o
