
gcc pipe_thread_mult.c -pthread -o ptm.o
./ptm.o
